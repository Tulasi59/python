"""1) What do you understand by Django?
2) What does Of Django Field Class types do?
3) Does Django Follow Architectural pattern?
4) Clarify the architecture of Django?
5) Is Django stable or not?
6) Is Django a high level or low-level framework?
7) How does Django work?
8) What is the name of the Foundation which manages Django web framework?
9) Name the features available in Django web framework?
10) What are the advantages of using Django for web development?
11) What is the process of creating a project in Django?
12) Is Django a content management system (CMS)?
13) What does the Django templates contain?
14) What is the use of session framework in Django?
15) How can you set up static files in Django?
16) How to use file based sessions?
17) What is some typical usage of middlewares in Django?
18) What is the usage of Django-admin.py and manage.py?
19) What are signals in Django ?
20) Is Django free?
21) Django is based on which design pattern.
22) When and who create Django?
23) List server requirement to install Django Framework.
24) List the database backends supported by Django Framework?
25) What is recommended way to install Django?

https://www.onlineinterviewquestions.com/django-interview-questions/
https://intellipaat.com/blog/interview-question/django-interview-questions/
https://data-flair.training/blogs/django-interview-questions/

https://www.edureka.co/blog/interview-questions/django-interview-questions/
"""
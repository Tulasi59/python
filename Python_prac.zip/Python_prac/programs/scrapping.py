import requests
from bs4 import BeautifulSoup

url="https://onlinecoursetutorials.com/interview-questions/django-interview-questions/"
r = requests.get(url)
soup= BeautifulSoup(r.content,"html.parser")
# print(soup)
div = soup.find('div',attrs={'class':'the_content'})
# print(div)
data = div.find_all('strong')[7].text
print(data)
# for i in data:
    # print(i)